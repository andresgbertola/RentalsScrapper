﻿using System;
using System.Globalization;
using System.Text.RegularExpressions;

namespace Alquileres.Domain
{
    public class Finding
    {
        public string Bedrooms { get; set; }

        public string Title { get; set; }

        public string Url { get; set; }

        public BuildingType BuildingType { get; set; }

        public FinderSources FinderSource { get; set; }

        public int? BedroomsCount => GetBedroomsCount();

        public string PublishDateText { get; set; }

        public DateTime? PublishDate => ParseDate();

        public string PriceText { get; set; }

        private DateTime? ParseDate()
        {
            if (DateTime.TryParse(PublishDateText, CultureInfo.CreateSpecificCulture("es-Ar"), DateTimeStyles.None, out DateTime result))
            {
                return result;
            }

            return null;
        }

        private int? GetBedroomsCount()
        {
            if (int.TryParse(Regex.Replace(this.Bedrooms, @"[^\d]", ""), out int value))
            {
                return value;
            }

            return null;
        }
    }

    public enum BuildingType
    {
        House,
        Apartment,
        Unknown
    }
}