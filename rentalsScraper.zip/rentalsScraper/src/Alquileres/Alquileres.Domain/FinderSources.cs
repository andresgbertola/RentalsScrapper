﻿namespace Alquileres.Domain
{
    public enum FinderSources
    {
        ABInmobiliaria,
        Gaggioti,
        MasPocoVendo,
        Facebook,
        CGInmobiliaria,
        CentroLaPropiedad,
        BMasB,
        Brega,
        Connecta,
        DireccionInmobiliaria,
        Remax,
        Oikos,
        Tobke,
        Bernini,
        Odn,
        EspaciosUrbanos,
        Boidi,
        Lorenzetti,
        Trovare,
        Wade,
        Domus,
        Trivelli
    }
}