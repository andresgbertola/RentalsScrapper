﻿using System;
using System.Globalization;

namespace Alquileres.Domain
{
    public class FacebookFinding
    {
        public string Title { get; set; }
        public string AlternativeTitle { get; set; }
        public string Url { get; set; }
        public string PublishDateText { get; set; }
        public DateTime? PublishDate => ParseDate();
        public FinderSources FinderSource { get; set; }

        private DateTime? ParseDate()
        {
            if (!string.IsNullOrWhiteSpace(PublishDateText))
            {
                var index = PublishDateText.IndexOf(",");
                var parsed = PublishDateText.Substring(index + 1).Trim().Replace("at ", "");

                if (DateTime.TryParse(parsed, CultureInfo.CreateSpecificCulture("en-US"), DateTimeStyles.None, out DateTime result))
                {
                    return result;
                }
            }

            return null;
        }
    }
}