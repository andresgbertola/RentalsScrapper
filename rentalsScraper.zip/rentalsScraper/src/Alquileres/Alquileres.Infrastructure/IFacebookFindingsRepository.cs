﻿using Alquileres.Domain;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Alquileres.Infrastructure
{
    public interface IFacebookFindingsRepository
    {
        Task<bool> CreateNewAsync(FacebookFinding finding);

        Task<IEnumerable<FacebookFinding>> GetAllAsync();

        Task<IEnumerable<FacebookFinding>> GetInterestedAsync();

        Task<IEnumerable<FacebookFinding>> GetNotInterestedAsync();

        Task<IEnumerable<FacebookFinding>> GetUnmarkedAsync();

        void MarkAsInterested(FacebookFinding finding);

        void MarkAsNotInterested(FacebookFinding finding);
    }
}