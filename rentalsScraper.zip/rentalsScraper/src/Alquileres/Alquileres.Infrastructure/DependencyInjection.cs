﻿using Microsoft.Extensions.DependencyInjection;

namespace Alquileres.Infrastructure
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services)
        {
            services.AddSingleton<IFindingsRepository, FindingsRepository>();
            services.AddSingleton<IFacebookFindingsRepository, FacebookFindingsRepository>();
            return services;
        }
    }
}