﻿using Alquileres.Domain;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Alquileres.Infrastructure
{
    public interface IFindingsRepository
    {
        Task<bool> CreateNewAsync(Finding finding);

        Task<IEnumerable<Finding>> GetAllAsync();

        Task<IEnumerable<Finding>> GetUnmarkedAsync();

        void MarkAsInterested(Finding finding);

        void MarkAsNotInterested(Finding finding);

        Task<IEnumerable<Finding>> GetInterestedAsync();

        Task<IEnumerable<Finding>> GetNotInterestedAsync();

        void MarkAsNotNotLongerAvailable(Finding finding);

        Task<IEnumerable<Finding>> GetNotLongerAvailableAsync();
    }
}