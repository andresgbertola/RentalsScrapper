﻿using Alquileres.Domain;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Alquileres.Infrastructure
{
    internal class FindingsRepository : IFindingsRepository
    {
        private const string _rootRepositoryFolder = @"C:\Personal\rentalsScraper\AlquileresDB";
        private const string _foundFolder = "Found";
        private const string _interested = "Interested";
        private const string _notInterested = "NotInterested";
        private const string _notLongerAvailable = "NotLongerAvailable";

        private string GetFoundFullPath(string name) => Path.Combine(_foundDirectoryPath, $"{ReplaceInvalidChars(name)}.json");

        private string GetInterestedFullPath(string name) => Path.Combine(_interestedDirectoryPath, $"{ReplaceInvalidChars(name)}.json");

        private string GetNotInterestedFullPath(string name) => Path.Combine(_notInterestedDirectoryPath, $"{ReplaceInvalidChars(name)}.json");

        private string GetNotLongerAvailableFullPath(string name) => Path.Combine(_notLongerAvailableDirectoryPath, $"{ReplaceInvalidChars(name)}.json");

        private static string _foundDirectoryPath = Path.Combine(_rootRepositoryFolder, _foundFolder);
        private static string _interestedDirectoryPath = Path.Combine(_rootRepositoryFolder, _interested);
        private static string _notInterestedDirectoryPath = Path.Combine(_rootRepositoryFolder, _notInterested);
        private static string _notLongerAvailableDirectoryPath = Path.Combine(_rootRepositoryFolder, _notLongerAvailable);

        private string ReplaceInvalidChars(string filename)
        {
            return string.Join("_", filename.Split(Path.GetInvalidFileNameChars()));
        }

        public async Task<bool> CreateNewAsync(Finding finding)
        {
            var filepath = GetFoundFullPath(finding.Url);
            var isNew = !File.Exists(filepath);
            File.WriteAllText(filepath, finding.ToJson());

            return isNew;
        }

        public void MarkAsInterested(Finding finding)
        {
            var path = GetInterestedFullPath(finding.Url);

            var interestedPath = GetNotInterestedFullPath(finding.Url);
            if (File.Exists(interestedPath))
                File.Delete(interestedPath);

            var notLongerAvailable = GetNotLongerAvailableFullPath(finding.Url);
            if (File.Exists(notLongerAvailable))
                File.Delete(notLongerAvailable);

            if (!File.Exists(path))
                File.Copy(GetFoundFullPath(finding.Url), GetInterestedFullPath(finding.Url));
        }

        public void MarkAsNotInterested(Finding finding)
        {
            var path = GetNotInterestedFullPath(finding.Url);

            var interestedPath = GetInterestedFullPath(finding.Url);
            if (File.Exists(interestedPath))
                File.Delete(interestedPath);

            var notLongerAvailable = GetNotLongerAvailableFullPath(finding.Url);
            if (File.Exists(notLongerAvailable))
                File.Delete(notLongerAvailable);

            if (!File.Exists(path))
                File.Copy(GetFoundFullPath(finding.Url), GetNotInterestedFullPath(finding.Url));
        }

        public void MarkAsNotNotLongerAvailable(Finding finding)
        {
            var path = GetNotInterestedFullPath(finding.Url);

            var interestedPath = GetInterestedFullPath(finding.Url);
            if (File.Exists(interestedPath))
                File.Delete(interestedPath);

            var notInterestedPath = GetNotInterestedFullPath(finding.Url);
            if (File.Exists(notInterestedPath))
                File.Delete(notInterestedPath);

            if (!File.Exists(path))
                File.Copy(GetFoundFullPath(finding.Url), GetNotLongerAvailableFullPath(finding.Url));
        }

        public Task<IEnumerable<Finding>> GetAllAsync()
        {
            var jsonFiles = Directory.GetFiles(_foundDirectoryPath, "*.json");
            return Task.FromResult(jsonFiles.Select(x => File.ReadAllText(x).FromJson<Finding>()));
        }

        public Task<IEnumerable<Finding>> GetInterestedAsync()
        {
            var jsonFiles = Directory.GetFiles(_interestedDirectoryPath, "*.json");
            return Task.FromResult(jsonFiles.Select(x => File.ReadAllText(x).FromJson<Finding>()));
        }

        public Task<IEnumerable<Finding>> GetNotInterestedAsync()
        {
            var jsonFiles = Directory.GetFiles(_notInterestedDirectoryPath, "*.json");
            return Task.FromResult(jsonFiles.Select(x => File.ReadAllText(x).FromJson<Finding>()));
        }

        public Task<IEnumerable<Finding>> GetNotLongerAvailableAsync()
        {
            var jsonFiles = Directory.GetFiles(_notLongerAvailableDirectoryPath, "*.json");
            return Task.FromResult(jsonFiles.Select(x => File.ReadAllText(x).FromJson<Finding>()));
        }

        public Task<IEnumerable<Finding>> GetUnmarkedAsync()
        {
            var jsonFiles = Directory.GetFiles(_foundDirectoryPath, "*.json");
            var markedJsonFiles = Directory.GetFiles(_interestedDirectoryPath, "*.json")
                .Union(Directory.GetFiles(_notInterestedDirectoryPath, "*.json"))
                .Union(Directory.GetFiles(_notLongerAvailableDirectoryPath, "*.json"));

            var unmarkedJsonFiles = jsonFiles.Where(x => !markedJsonFiles.Any(y => Path.GetFileName(y) == Path.GetFileName(x)));

            return Task.FromResult(unmarkedJsonFiles.Select(x => File.ReadAllText(x).FromJson<Finding>()));
        }
    }
}