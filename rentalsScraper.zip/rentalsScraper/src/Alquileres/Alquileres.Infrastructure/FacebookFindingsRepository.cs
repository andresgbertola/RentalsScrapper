﻿using Alquileres.Domain;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Alquileres.Infrastructure
{
    internal class FacebookFindingsRepository : IFacebookFindingsRepository
    {
        private const string _rootRepositoryFolder = @"C:\Personal\FacebookFindings";
        private const string _foundFolder = "Found";
        private const string _interested = "Interested";
        private const string _notInterested = "NotInterested";

        private string GetFoundFullPath(string name) => Path.Combine(_foundDirectoryPath, $"{ReplaceInvalidChars(name)}.json");

        private string GetInterestedFullPath(string name) => Path.Combine(_interestedDirectoryPath, $"{ReplaceInvalidChars(name)}.json");

        private string GetNotInterestedFullPath(string name) => Path.Combine(_notInterestedDirectoryPath, $"{ReplaceInvalidChars(name)}.json");

        private static string _foundDirectoryPath = Path.Combine(_rootRepositoryFolder, _foundFolder);
        private static string _interestedDirectoryPath = Path.Combine(_rootRepositoryFolder, _interested);
        private static string _notInterestedDirectoryPath = Path.Combine(_rootRepositoryFolder, _notInterested);

        private string ReplaceInvalidChars(string filename)
        {
            return string.Join("_", filename.Split(Path.GetInvalidFileNameChars()));
        }

        public async Task<bool> CreateNewAsync(FacebookFinding finding)
        {
            var filePath = GetFoundFullPath(GetFileName(finding));
            var isNew = !File.Exists(filePath);

            File.WriteAllText(filePath, finding.ToJson());
            return isNew;
        }

        public void MarkAsInterested(FacebookFinding finding)
        {
            var path = GetInterestedFullPath(GetFileName(finding));

            var interestedPath = GetNotInterestedFullPath(GetFileName(finding));
            if (File.Exists(interestedPath))
                File.Delete(interestedPath);

            if (!File.Exists(path))
                File.Copy(GetFoundFullPath(GetFileName(finding)), GetInterestedFullPath(GetFileName(finding)));
        }

        public void MarkAsNotInterested(FacebookFinding finding)
        {
            var path = GetNotInterestedFullPath(GetFileName(finding));

            var interestedPath = GetInterestedFullPath(GetFileName(finding));
            if (File.Exists(interestedPath))
                File.Delete(interestedPath);

            if (!File.Exists(path))
                File.Copy(GetFoundFullPath(GetFileName(finding)), GetNotInterestedFullPath(GetFileName(finding)));
        }

        public Task<IEnumerable<FacebookFinding>> GetAllAsync()
        {
            var jsonFiles = Directory.GetFiles(_foundDirectoryPath, "*.json");
            return Task.FromResult(jsonFiles.Select(x => File.ReadAllText(x).FromJson<FacebookFinding>()));
        }

        public Task<IEnumerable<FacebookFinding>> GetInterestedAsync()
        {
            var jsonFiles = Directory.GetFiles(_interestedDirectoryPath, "*.json");
            return Task.FromResult(jsonFiles.Select(x => File.ReadAllText(x).FromJson<FacebookFinding>()));
        }

        public Task<IEnumerable<FacebookFinding>> GetNotInterestedAsync()
        {
            var jsonFiles = Directory.GetFiles(_notInterestedDirectoryPath, "*.json");
            return Task.FromResult(jsonFiles.Select(x => File.ReadAllText(x).FromJson<FacebookFinding>()));
        }

        public Task<IEnumerable<FacebookFinding>> GetUnmarkedAsync()
        {
            var jsonFiles = Directory.GetFiles(_foundDirectoryPath, "*.json");
            var markedJsonFiles = Directory.GetFiles(_interestedDirectoryPath, "*.json").Union(Directory.GetFiles(_notInterestedDirectoryPath, "*.json"));

            var unmarkedJsonFiles = jsonFiles.Where(x => !markedJsonFiles.Any(y => Path.GetFileName(y) == Path.GetFileName(x)));

            return Task.FromResult(unmarkedJsonFiles.Select(x => File.ReadAllText(x).FromJson<FacebookFinding>()));
        }

        private string GetFileName(FacebookFinding facebookFinding)
        {
            var pattern = ".com/[A-z]*[.]*[A-z]*";
            return $"{Regex.Match(facebookFinding.Url, pattern).Value.Replace(".com/", "")}{facebookFinding.PublishDate}";
        }
    }
}