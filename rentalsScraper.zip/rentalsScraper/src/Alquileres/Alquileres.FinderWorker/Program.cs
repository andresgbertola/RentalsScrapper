using Alquileres.FinderWorker.Finders;
using Alquileres.Infrastructure;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using PuppeteerSharp;

namespace Alquileres.FinderWorker
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureServices((hostContext, services) =>
                {
                    services.AddHostedService<Worker>();
                    services.AddInfrastructure();
                    services.AddSingleton<IFinderRobot, FinderRobot>();

                    services.AddSingleton<Browser>(BrowserFactory.CreateBrowser());
                    services.AddSingleton<ABFinder>();
                    services.AddSingleton<GaggiottiFinder>();
                    services.AddSingleton<MasPocoVendoFinder>();
                    services.AddSingleton<CGFinder>();
                    services.AddSingleton<BmasBFinder>();
                    services.AddSingleton<BregaFinder>();
                    services.AddSingleton<CentroLaPropiedadFinder>();
                    services.AddSingleton<ConnectaFinder>();
                    services.AddSingleton<DireccionInmobiliariaFinder>();
                    services.AddSingleton<RemaxFinder>();
                    services.AddSingleton<FacebookFinder>();
                    services.AddSingleton<TrivelliFinder>();
                    services.AddSingleton<OdnFinder>();
                });
    }
}