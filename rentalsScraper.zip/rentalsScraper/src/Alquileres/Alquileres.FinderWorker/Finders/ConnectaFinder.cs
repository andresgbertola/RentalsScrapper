﻿using Alquileres.Domain;
using PuppeteerSharp;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Alquileres.FinderWorker.Finders
{
    public class ConnectaFinder : IFinder
    {
        private const string _source = "https://connectainmobiliaria.com.ar/page/{0}?_sort=&s=&post_type=hp_listing&_category=343&bedrooms=2&bathrooms=&pets=";
        private readonly Browser _browser;

        public FinderSources FinderSource => FinderSources.Connecta;

        public ConnectaFinder(Browser browser)
        {
            this._browser = browser;
        }

        public async Task<IEnumerable<Finding>> ExecuteAsync()
        {
            var allFindings = new List<Finding>();

            var lastPage = false;
            var pageNumber = 1;
            while (!lastPage)
            {
                var page = await _browser.NewPageAsync();
                var fullUrl = string.Format(_source, pageNumber);
                await page.GoToAsync(fullUrl);

                var items = "Array.from(document.getElementsByClassName('hp-listing__title')).map(x => ({ bedrooms: 0, title: x.innerText, url: x.childNodes[0].href }) )";
                var findings = await page.EvaluateExpressionAsync<List<Finding>>(items);
                findings.ForEach(x => { x.BuildingType = BuildingType.Unknown; x.FinderSource = FinderSources.Connecta; });

                if (findings.Any())
                {
                    allFindings.AddRange(findings);
                }
                else
                {
                    lastPage = true;
                }
                await page.DisposeAsync();
                pageNumber++;
            }

            return allFindings;
        }
    }
}