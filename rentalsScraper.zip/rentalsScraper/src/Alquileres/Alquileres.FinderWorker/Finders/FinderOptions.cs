﻿namespace Alquileres.FinderWorker.Finders
{
    public class FinderOptions
    {
        public int Bedrooms { get; set; }

        public bool Garage { get; set; }
    }
}