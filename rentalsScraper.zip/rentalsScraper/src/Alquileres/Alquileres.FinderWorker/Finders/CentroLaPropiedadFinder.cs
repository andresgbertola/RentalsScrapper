﻿using Alquileres.Domain;
using PuppeteerSharp;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Alquileres.FinderWorker.Finders
{
    public class CentroLaPropiedadFinder : IFinder
    {
        private const string _source = "http://www.centroinmobiliariosrl.com.ar/alquileres.php";
        private readonly Browser _browser;

        public FinderSources FinderSource => FinderSources.CentroLaPropiedad;

        public CentroLaPropiedadFinder(Browser browser)
        {
            this._browser = browser;
        }

        public async Task<IEnumerable<Finding>> ExecuteAsync()
        {
            var allFindings = new List<Finding>();

            var page = await _browser.NewPageAsync();
            await page.GoToAsync(_source);

            var items = "Array.from(document.getElementsByClassName('row m-0 item-destacados')).map(x => ({ bedrooms: 0, title: x.innerText, url: x.childNodes[3].childNodes[1].childNodes[1].childNodes[1].href }) )";

            var findings = await page.EvaluateExpressionAsync<List<Finding>>(items);
            findings.ForEach(x => { x.BuildingType = BuildingType.Unknown; x.FinderSource = FinderSources.CentroLaPropiedad; });
            allFindings.AddRange(findings);
            await page.DisposeAsync();

            return allFindings;
        }
    }
}