﻿using Alquileres.Domain;
using PuppeteerSharp;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Alquileres.FinderWorker.Finders
{
    public class BmasBFinder : IFinder
    {
        private const string _source = "https://bmasbinmobiliaria.com.ar/resultados/?status%5B%5D=alquiler&location%5B%5D=rafaela&bedrooms=2&max-price=";
        private readonly Browser _browser;

        public FinderSources FinderSource => FinderSources.BMasB;

        public BmasBFinder(Browser browser)
        {
            this._browser = browser;
        }

        public async Task<IEnumerable<Finding>> ExecuteAsync()
        {
            var allFindings = new List<Finding>();

            var page = await _browser.NewPageAsync();
            await page.GoToAsync(_source);

            var items = "Array.from(document.getElementsByClassName('btn btn-primary btn-item item-no-footer')).map(x => ({ bedrooms: 0, title: x.parentNode.parentNode.parentNode.innerText, url: x.href }) )";

            var findings = await page.EvaluateExpressionAsync<List<Finding>>(items);
            findings.ForEach(x => { x.BuildingType = BuildingType.Unknown; x.FinderSource = FinderSources.BMasB; });
            allFindings.AddRange(findings);

            await page.DisposeAsync();

            return allFindings;
        }
    }
}