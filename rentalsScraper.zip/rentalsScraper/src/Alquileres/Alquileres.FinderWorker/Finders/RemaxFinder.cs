﻿using Alquileres.Domain;
using PuppeteerSharp;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Alquileres.FinderWorker.Finders
{
    public class RemaxFinder : IFinder
    {
        private const string _pageNumberAttr = "{{pageNumber}}";
        private string _url = $"https://www.remax.com.ar/listings/rent?page={_pageNumberAttr}&pageSize=24&sort=-createdAt&in:operationId=2&in:typeId=12,21,23,14,15,9,10,11,1,2,3,4,5,6,7,8&locations=in::::17336@Santa%20Fe-%20Castellanos-%20%3Cb%3ERafaela%3C%2Fb%3E:::&filterCount=1&viewMode=list";
        private readonly Browser _browser;

        public FinderSources FinderSource => FinderSources.Remax;

        public RemaxFinder(Browser browser)
        {
            this._browser = browser;
        }

        private (string Url, BuildingType BuildingType)[] _sources => new (string Url, BuildingType BuildingType)[]
        {
            (_url, BuildingType.Unknown)
        };

        public async Task<IEnumerable<Finding>> ExecuteAsync()
        {
            var allFindings = new List<Finding>();

            var lastPage = false;
            var pageNumber = 0;
            while (!lastPage)
            {
                var fullUrl = _url.Replace(_pageNumberAttr, pageNumber.ToString());
                var page = await _browser.NewPageAsync();
                await page.GoToAsync(fullUrl);

                var items = "Array.from(document.getElementsByClassName('mat-ripple info')).map(x => ({ bedrooms: 0, title: x.innerText, url: x.href }))";
                var findings = await page.EvaluateExpressionAsync<List<Finding>>(items);

                var counter = 0;
                await page.DisposeAsync();

                foreach (var finding in findings)
                {
                    var childPage = await _browser.NewPageAsync();
                    await childPage.GoToAsync(fullUrl);
                    var selectors = await childPage.QuerySelectorAllAsync("#wrapper > div.mat-ripple.info");
                    await selectors[counter].ClickAsync();

                    var pages = await _browser.PagesAsync();
                    await childPage.WaitForNavigationAsync();
                    finding.FinderSource = FinderSources.Remax;
                    finding.Url = childPage.Url;
                    counter++;

                    await childPage.DisposeAsync();
                }

                if (findings.Any())
                {
                    allFindings.AddRange(findings);
                }
                else
                {
                    lastPage = true;
                }

                pageNumber++;
            }

            return allFindings;
        }
    }
}