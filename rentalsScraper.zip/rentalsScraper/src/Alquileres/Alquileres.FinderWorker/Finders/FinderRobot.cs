﻿using Alquileres.Infrastructure;
using PuppeteerSharp;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Alquileres.FinderWorker.Finders
{
    public class FinderRobot : IFinderRobot
    {
        private readonly IFindingsRepository _findingsRepository;
        private readonly IFacebookFindingsRepository _facebookFindingsRepository;
        private readonly Browser _browser;
        private readonly FacebookFinder _facebookFinder;
        private readonly IFinder[] _finders;

        public FinderRobot(IFindingsRepository findingsRepository,
            IFacebookFindingsRepository facebookFindingsRepository,
            Browser browser,
            RemaxFinder remaxFinder,
            ABFinder aBFinder,
            GaggiottiFinder gaggiottiFinder,
            MasPocoVendoFinder masPocoVendoFinder,
            CGFinder cGFinder,
            BmasBFinder bmasBFinder,
            BregaFinder bregaFinder,
            CentroLaPropiedadFinder centroLaPropiedadFinder,
            ConnectaFinder connectaFinder,
            DireccionInmobiliariaFinder direccionInmobiliariaFinder,
            TrivelliFinder trivelliFinder,
            FacebookFinder facebookFinder,
            OdnFinder odnFinder)
        {
            this._findingsRepository = findingsRepository;
            this._facebookFindingsRepository = facebookFindingsRepository;
            this._browser = browser;
            this._facebookFinder = facebookFinder;
            this._finders = new IFinder[]
            {
                remaxFinder,
                aBFinder,
                gaggiottiFinder,
                masPocoVendoFinder,
                cGFinder,
                bmasBFinder,
                bregaFinder,
                centroLaPropiedadFinder,
                connectaFinder,
                direccionInmobiliariaFinder,
                trivelliFinder,
                odnFinder
            };
        }

        public async Task ExecuteFindersAsync()
        {
            var tasks = _finders.Select(x => ExecuteFinderAsync(x)).ToArray();

            var findingsCountList = await Task.WhenAll(tasks);
            var facebookFindings = 0;

            Console.WriteLine($"Findings: {findingsCountList.Sum()}");

            Console.WriteLine("Executing facebook finder..");

            var fbFindings = await _facebookFinder.ExecuteAsync();
            foreach (var finding in fbFindings)
                if (await _facebookFindingsRepository.CreateNewAsync(finding)) facebookFindings++;

            Console.WriteLine("All done..");
            Console.WriteLine($"Findings: {findingsCountList.Sum()}");
            Console.WriteLine($"Facebook findings: {facebookFindings}");

            await _browser.CloseAsync();
        }

        private async Task<int> ExecuteFinderAsync(IFinder finder)
        {
            var findingsCount = 0;
            try
            {
                Console.WriteLine($"Executing finder {finder.FinderSource}..");
                var findings = await finder.ExecuteAsync();

                foreach (var finding in findings)
                {
                    if (await _findingsRepository.CreateNewAsync(finding))
                    {
                        findingsCount++;
                    }
                }
                Console.WriteLine($"Executing finder {finder.FinderSource}..OK");
            }
            catch (Exception e)
            {
                findingsCount = 0;
                Console.WriteLine($"Finder {finder.FinderSource} failed: {e}");
            }

            return findingsCount;
        }
    }
}