﻿using Alquileres.Domain;
using PuppeteerSharp;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Alquileres.FinderWorker.Finders
{
    public class TrivelliFinder : IFinder
    {
        private const string _source = "http://www.abinmobiliaria.com.ar/listing?user_id=245&purpose=rent&type=Departamento";
        private readonly Browser _browser;

        public FinderSources FinderSource => FinderSources.Trivelli;

        public TrivelliFinder(Browser browser)
        {
            this._browser = browser;
        }

        public async Task<IEnumerable<Finding>> ExecuteAsync()
        {
            var allFindings = new List<Finding>();

            var page = await _browser.NewPageAsync();
            await page.GoToAsync(_source);

            var items = "Array.from(document.getElementsByClassName('property-title')).map(x => ({ bedrooms: 0, title: x.parentElement.innerText, url: x.children[0].href }) )";

            var findings = await page.EvaluateExpressionAsync<List<Finding>>(items);
            findings.ForEach(x => { x.BuildingType = BuildingType.Unknown; x.FinderSource = FinderSources.Trivelli; });
            allFindings.AddRange(findings);

            await page.DisposeAsync();

            return allFindings;
        }
    }
}