﻿using Alquileres.Domain;
using PuppeteerSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Alquileres.FinderWorker.Finders
{
    public class FacebookFinder : IFacebookFinder
    {
        public FacebookFinder(Browser browser)
        {
            this._browser = browser;
        }

        private const int _days = 20;
        private readonly Browser _browser;

        private (string Url, FinderSources FindingSource)[] _sources = new (string, FinderSources)[]
        {
            ("https://www.facebook.com/oikosnegociosinmobiliarios/", FinderSources.Oikos),
            ("https://www.facebook.com/inmobiliariaespacios.urbanos", FinderSources.EspaciosUrbanos),
            ("https://www.facebook.com/Bernini-Inmobiliaria-110670070397328/?ref=py_c", FinderSources.Bernini),
            ("https://www.facebook.com/inmobiliaria.boidi", FinderSources.Boidi),
            ("https://www.facebook.com/TrovareInmobiliaria", FinderSources.Trovare),
            ("https://www.facebook.com/wade.inmobiliaria", FinderSources.Wade),
            ("https://www.facebook.com/bregainmobiliaria", FinderSources.Brega),
            ("https://www.facebook.com/TobkeInmobiliaria", FinderSources.Tobke),
            ("https://www.facebook.com/d.inmobiliaria", FinderSources.DireccionInmobiliaria),
            ("https://www.facebook.com/BB-Administracion-de-propiedades-1575567349405527", FinderSources.BMasB),
            ("https://www.facebook.com/domus.propiedades.7", FinderSources.Domus),
            ("https://www.facebook.com/centroinmobiliariorafaela/?ref=py_c", FinderSources.CentroLaPropiedad),
            ("https://www.facebook.com/propiedadeslorenzetti/?ref=py_c", FinderSources.Lorenzetti),
            ("https://www.facebook.com/odninmobiliaria/", FinderSources.Odn),
            ("https://www.facebook.com/abinmobiliariasrl", FinderSources.ABInmobiliaria),
            ("https://www.facebook.com/trivellicremieuxrafaela/", FinderSources.Trivelli)
        };

        public async Task<IEnumerable<FacebookFinding>> ExecuteAsync()
        {
            var allFindings = new List<FacebookFinding>();
            var random = new Random();
            //foreach (var s in _sources.OrderBy(x => Guid.NewGuid())) // Randomizes order
            foreach (var s in _sources)
            {
                Console.WriteLine($"Finding in {s.Url}");
                var dateLimit = DateTime.Today.AddDays(-_days);

                // Delays to avoid blocks;
                await Task.Delay(random.Next(300, 2000));

                var page = await _browser.NewPageAsync();
                var fullUrl = $"{s.Url}";
                await page.GoToAsync(fullUrl);

                var scroll = "window.scrollTo(0,document.body.scrollHeight);";
                // Scrolls i times to get old posts.
                for (int i = 0; i < 2; i++)
                {
                    await Task.Delay(random.Next(150, 600));
                    await page.EvaluateExpressionAsync(scroll);
                }

                var items = "Array.from(document.getElementsByClassName('timestampContent')).map(x => ({ Title: x.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode?.childNodes[0]?.childNodes[1]?.childNodes[0]?.childNodes[2]?.childNodes[1]?.childNodes[0]?.innerText, Url: x.parentNode.parentNode.parentNode.parentNode.childNodes[0].childNodes[0].href, AlternativeTitle: x.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.childNodes[0]?.childNodes[1]?.childNodes[0]?.childNodes[2]?.childNodes[0]?.innerText, PublishDateText: x.parentElement.attributes[1].textContent }))";
                var findings = await page.EvaluateExpressionAsync<List<FacebookFinding>>(items);

                findings = findings.Where(x => x.PublishDate.HasValue && x.PublishDate.Value > dateLimit).ToList();

                findings.ForEach(x => x.FinderSource = s.FindingSource);

                await page.DisposeAsync();

                allFindings.AddRange(findings);
            }

            return allFindings;
        }
    }
}