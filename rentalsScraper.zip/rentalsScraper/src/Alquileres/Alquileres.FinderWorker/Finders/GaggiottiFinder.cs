﻿using Alquileres.Domain;
using PuppeteerSharp;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Alquileres.FinderWorker.Finders
{
    public class GaggiottiFinder : IFinder
    {
        private const string _departmentsUrl = "http://www.gaggiotti.com.ar/propiedades-alquiler/departamento-4/";
        private const string _housesUrl = "http://www.gaggiotti.com.ar/propiedades-alquiler/casa-6/";
        private readonly Browser _browser;

        public FinderSources FinderSource => FinderSources.Gaggioti;

        public GaggiottiFinder(Browser browser)
        {
            this._browser = browser;
        }

        private (string Url, BuildingType BuildingType)[] _sources => new (string Url, BuildingType BuildingType)[]
        {
            (_departmentsUrl, BuildingType.Apartment),
            (_housesUrl, BuildingType.House)
        };

        public async Task<IEnumerable<Finding>> ExecuteAsync()
        {
            var allFindings = new List<Finding>();

            foreach (var s in _sources)
            {
                var lastPage = false;
                var pageNumber = 1;
                while (!lastPage)
                {
                    var page = await _browser.NewPageAsync();
                    var fullUrl = $"{s.Url}pagina-{pageNumber}/";
                    await page.GoToAsync(fullUrl);

                    var hasResults = "document.getElementsByClassName('text-center sin')[0] == null";
                    lastPage = !(await page.EvaluateExpressionAsync<bool>(hasResults));

                    if (!lastPage)
                    {
                        var items = "Array.from(document.getElementsByClassName('propiedad')).map(x => ({ bedrooms: 0, title: x.children[0].innerText, url: x.href }))";
                        var findings = await page.EvaluateExpressionAsync<List<Finding>>(items);
                        findings.ForEach(x => { x.BuildingType = s.BuildingType; x.FinderSource = FinderSources.Gaggioti; });

                        if (findings.Any())
                        {
                            allFindings.AddRange(findings);
                        }
                        else
                        {
                            lastPage = true;
                        }
                    }
                    await page.DisposeAsync();

                    pageNumber++;
                }
            }

            return allFindings;
        }
    }
}