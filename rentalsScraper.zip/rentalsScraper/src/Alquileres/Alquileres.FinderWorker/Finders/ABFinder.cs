﻿using Alquileres.Domain;
using PuppeteerSharp;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Alquileres.FinderWorker.Finders
{
    public class ABFinder : IFinder
    {
        private const string _departmentsUrl = "http://www.abinmobiliaria.com.ar/listing?user_id=245&purpose=rent&type=Departamento";
        private const string _housesUrl = "http://www.abinmobiliaria.com.ar/listing?user_id=245&purpose=rent&type=Casa";
        private const string _duplexUrl = "http://www.abinmobiliaria.com.ar/listing?user_id=245&purpose=rent&type=D%C3%BAplex";
        private readonly Browser _browser;

        public FinderSources FinderSource => FinderSources.ABInmobiliaria;

        private (string Url, BuildingType BuildingType)[] _sources => new (string Url, BuildingType BuildingType)[]
        {
            (_departmentsUrl, BuildingType.Apartment),
            (_housesUrl, BuildingType.House),
            (_duplexUrl, BuildingType.House)
        };

        public ABFinder(Browser browser)
        {
            this._browser = browser;
        }

        public async Task<IEnumerable<Finding>> ExecuteAsync()
        {
            var allFindings = new List<Finding>();

            foreach (var s in _sources)
            {
                var page = await _browser.NewPageAsync();
                await page.GoToAsync(s.Url);

                var items = "Array.from(document.getElementsByClassName('fa fa-bed')).map(x => ({ bedrooms: x.parentElement.innerText, title: x.parentElement.parentElement.parentElement.parentElement.innerText, url: x.parentElement.parentElement.parentElement.parentElement.firstElementChild.href }) )";

                var findings = await page.EvaluateExpressionAsync<List<Finding>>(items);
                findings.ForEach(x => { x.BuildingType = s.BuildingType; x.FinderSource = FinderSources.ABInmobiliaria; });
                allFindings.AddRange(findings);

                await page.DisposeAsync();
            }

            return allFindings;
        }
    }
}