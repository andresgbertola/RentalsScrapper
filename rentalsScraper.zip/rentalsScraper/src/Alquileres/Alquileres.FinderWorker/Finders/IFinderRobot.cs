﻿using System.Threading.Tasks;

namespace Alquileres.FinderWorker.Finders
{
    public interface IFinderRobot
    {
        Task ExecuteFindersAsync();
    }
}