﻿using Alquileres.Domain;
using PuppeteerSharp;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Alquileres.FinderWorker.Finders
{
    public class BregaFinder : IFinder
    {
        private const string _source = "http://www.bregainmobiliaria.com.ar/resultados-de-busqueda/?keyword=&status=en-alquiler&bedrooms=2";
        private readonly Browser _browser;

        public FinderSources FinderSource => FinderSources.Brega;

        public BregaFinder(Browser browser)
        {
            this._browser = browser;
        }

        public async Task<IEnumerable<Finding>> ExecuteAsync()
        {
            var allFindings = new List<Finding>();

            var page = await _browser.NewPageAsync();
            await page.GoToAsync(_source);

            var items = "Array.from(document.getElementsByClassName('property-title')).map(x => ({ bedrooms: 0, title: x.innerText, url: x.childNodes[0].href }) )";

            var findings = await page.EvaluateExpressionAsync<List<Finding>>(items);
            findings.ForEach(x => { x.BuildingType = BuildingType.Unknown; x.FinderSource = FinderSources.Brega; });
            allFindings.AddRange(findings);
            await page.DisposeAsync();

            return allFindings;
        }
    }
}