﻿using Alquileres.Domain;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Alquileres.FinderWorker.Finders
{
    public interface IFinder
    {
        Task<IEnumerable<Finding>> ExecuteAsync();

        FinderSources FinderSource { get; }
    }
}