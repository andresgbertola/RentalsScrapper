﻿using Alquileres.Domain;
using PuppeteerSharp;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Alquileres.FinderWorker.Finders
{
    public class DireccionInmobiliariaFinder : IFinder
    {
        private const string _departmentsUrl = "http://www.direccioninmob.com.ar/index.php/alquileres/departamentos";
        private const string _housesUrl = "http://www.direccioninmob.com.ar/index.php/alquileres/casas";
        private readonly Browser _browser;

        public FinderSources FinderSource => FinderSources.DireccionInmobiliaria;

        private (string Url, BuildingType BuildingType)[] _sources => new (string Url, BuildingType BuildingType)[]
        {
            (_departmentsUrl, BuildingType.Apartment),
            (_housesUrl, BuildingType.House)
        };

        public DireccionInmobiliariaFinder(Browser browser)
        {
            this._browser = browser;
        }

        public async Task<IEnumerable<Finding>> ExecuteAsync()
        {
            var allFindings = new List<Finding>();

            foreach (var s in _sources)
            {
                var page = await _browser.NewPageAsync();
                await page.GoToAsync(s.Url);

                var items = "Array.from(document.getElementsByClassName('item column-1')).map(x => ({ bedrooms: 0, title: x.innerText, url: x.childNodes[1].childNodes[1].href }) )";
                var items2 = "Array.from(document.getElementsByClassName('item column-2')).map(x => ({ bedrooms: 0, title: x.innerText, url: x.childNodes[1].childNodes[1].href }) )";

                var findings = (await page.EvaluateExpressionAsync<List<Finding>>(items)).Union(await page.EvaluateExpressionAsync<List<Finding>>(items2)).ToList();
                findings.ForEach(x => { x.BuildingType = s.BuildingType; x.FinderSource = FinderSources.DireccionInmobiliaria; });

                await page.DisposeAsync();

                allFindings.AddRange(findings);
            }

            return allFindings;
        }
    }
}