﻿using Alquileres.Domain;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Alquileres.FinderWorker.Finders
{
    public interface IFacebookFinder
    {
        Task<IEnumerable<FacebookFinding>> ExecuteAsync();
    }
}