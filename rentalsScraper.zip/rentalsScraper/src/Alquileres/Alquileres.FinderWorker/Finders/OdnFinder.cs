﻿using Alquileres.Domain;
using PuppeteerSharp;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Alquileres.FinderWorker.Finders
{
    public class OdnFinder : IFinder
    {
        private const string _source = "http://www.inmobiliariaodn.com.ar/Propiedades.aspx?page={0}";
        private readonly Browser _browser;

        public FinderSources FinderSource => FinderSources.Odn;

        public OdnFinder(Browser browser)
        {
            this._browser = browser;
        }

        public async Task<IEnumerable<Finding>> ExecuteAsync()
        {
            var allFindings = new List<Finding>();
            var url = _source;

            var lastPage = false;
            var pageNumber = 1;
            while (!lastPage)
            {
                var page = await _browser.NewPageAsync();
                var fullUrl = string.Format(_source, pageNumber);
                await page.GoToAsync(fullUrl);

                if (pageNumber == 1)
                {
                    await page.SelectAsync("#DDL_Operacion", "1");
                    await page.ClickAsync("#B_buscar");
                    await page.WaitForNavigationAsync();
                }

                var scroll = "window.scrollTo(0,document.body.scrollHeight);";
                // Scrolls i times to get old posts.
                for (int i = 0; i < 5; i++)
                {
                    await page.EvaluateExpressionAsync(scroll);
                }

                var items = "Array.from(document.getElementsByClassName('bottom-sec')).map(x => ({ bedrooms: 0, title: x.parentElement.innerText, url: x.children[0].href }))";
                var findings = await page.EvaluateExpressionAsync<List<Finding>>(items);
                findings.ForEach(x => { x.BuildingType = BuildingType.Unknown; x.FinderSource = FinderSources.Odn; });

                if (findings.Any())
                {
                    allFindings.AddRange(findings);
                }
                else
                {
                    lastPage = true;
                }

                await page.DisposeAsync();

                pageNumber++;
            }

            return allFindings;
        }
    }
}