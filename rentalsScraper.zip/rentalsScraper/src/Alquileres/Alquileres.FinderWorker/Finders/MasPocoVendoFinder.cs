﻿using Alquileres.Domain;
using PuppeteerSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Alquileres.FinderWorker.Finders
{
    public class MasPocoVendoFinder : IFinder
    {
        private const string _departmentsUrl = "https://www.maspocovendo.com/categoria/alquiler/MLA1473?D_BEDROOMS=2_2&lat=-31.25579&lon=-61.50194&distance=0";
        private const string _housesUrl = "https://www.maspocovendo.com/categoria/alquiler/MLA1467?D_BEDROOMS=2_2&lat=-31.25579&lon=-61.50194&distance=0";
        private const int _days = 20;
        private readonly Browser _browser;

        private (string Url, BuildingType BuildingType)[] _sources => new (string Url, BuildingType BuildingType)[]
        {
            (_departmentsUrl, BuildingType.Apartment),
            (_housesUrl, BuildingType.House)
        };

        public FinderSources FinderSource => FinderSources.MasPocoVendo;

        public MasPocoVendoFinder(Browser browser)
        {
            this._browser = browser;
        }

        public async Task<IEnumerable<Finding>> ExecuteAsync()
        {
            var allFindings = new List<Finding>();

            foreach (var s in _sources)
            {
                var lastPage = false;
                var pageNumber = 1;
                var dateLimit = DateTime.Today.AddDays(-_days);
                while (!lastPage)
                {
                    var page = await _browser.NewPageAsync();
                    var fullUrl = $"{s.Url}&page={pageNumber}/";
                    await page.GoToAsync(fullUrl);

                    var hasResults = "document.getElementsByClassName('empty text-primary text-center mt-3')[0] == null";
                    lastPage = !(await page.EvaluateExpressionAsync<bool>(hasResults));

                    if (!lastPage)
                    {
                        var items = "Array.from(document.getElementsByClassName('product-card-container px-2 px-sm-0')).map(x => ({ bedrooms: 2, title: x.childNodes[0].children[0].children[1].children[1].innerText, url: x.childNodes[0].href, publishDateText: x.childNodes[0].children[0].children[1].children[3].childNodes[2].innerText, priceText: x.childNodes[0].childNodes[0].childNodes[2].childNodes[4].innerText }))";
                        var findings = await page.EvaluateExpressionAsync<List<Finding>>(items);

                        findings = findings.Where(x => x.PublishDate.HasValue && x.PublishDate.Value > dateLimit).ToList();
                        if (findings.Any())
                        {
                            findings.ForEach(x => { x.BuildingType = s.BuildingType; x.FinderSource = FinderSources.MasPocoVendo; });
                            allFindings.AddRange(findings);
                        }
                        else
                        {
                            lastPage = true;
                        }
                    }
                    await page.DisposeAsync();

                    pageNumber++;
                }
            }

            return allFindings;
        }
    }
}