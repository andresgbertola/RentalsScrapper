﻿using Alquileres.Domain;
using PuppeteerSharp;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Alquileres.FinderWorker.Finders
{
    public class CGFinder : IFinder
    {
        private const string _url = "https://inmobiliaria-cg.com.ar/alquiler";
        private readonly Browser browser;

        public FinderSources FinderSource => FinderSources.CGInmobiliaria;

        public CGFinder(Browser _browser)
        {
            this.browser = _browser;
        }

        public async Task<IEnumerable<Finding>> ExecuteAsync()
        {
            var allFindings = new List<Finding>();

            var lastPage = false;
            var pageNumber = 1;
            while (!lastPage)
            {
                var fullUrl = pageNumber > 1 ? $"{_url}_{pageNumber.ToString("##")}" : _url;
                var page = await browser.NewPageAsync();
                await page.GoToAsync(fullUrl);

                if (!lastPage)
                {
                    var items = "Array.from(document.getElementsByClassName('alignnone wp-image-209 size-full')).map(x => ({ bedrooms: 0, title: x.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.innerText, url: x.parentNode.href }))";
                    var findings = await page.EvaluateExpressionAsync<List<Finding>>(items);
                    findings.ForEach(x => { x.BuildingType = BuildingType.Unknown; x.FinderSource = FinderSources.CGInmobiliaria; });

                    if (findings.Any())
                    {
                        allFindings.AddRange(findings);
                    }
                    else
                    {
                        lastPage = true;
                    }
                }
                await page.DisposeAsync();

                pageNumber++;
            }

            return allFindings;
        }
    }
}