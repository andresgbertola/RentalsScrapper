using Alquileres.FinderWorker.Finders;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

namespace Alquileres.FinderWorker
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;
        private readonly IFinderRobot _finderRobot;

        public Worker(ILogger<Worker> logger, IFinderRobot finderRobot)
        {
            _logger = logger;
            _finderRobot = finderRobot;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            var run = true;
            while (run && !stoppingToken.IsCancellationRequested)
            {
                _logger.LogInformation("Worker running at: {time}", DateTimeOffset.Now);

                try
                {
                    var sw = Stopwatch.StartNew();
                    await _finderRobot.ExecuteFindersAsync();
                    sw.Stop();
                    Console.WriteLine($"Ran in {sw.Elapsed.TotalSeconds}s");
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
                run = false;
            }

            Console.WriteLine("Press key to exit.");
            Console.ReadKey();
        }
    }
}