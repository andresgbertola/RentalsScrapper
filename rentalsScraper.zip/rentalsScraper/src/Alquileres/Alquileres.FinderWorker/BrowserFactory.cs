﻿using PuppeteerSharp;
using System.Threading.Tasks;

namespace Alquileres.FinderWorker
{
    public static class BrowserFactory
    {
        public async static Task<Browser> CreateBrowserAsync()
        {
            var options = new LaunchOptions()
            {
                Headless = false,
                ExecutablePath = @"C:\Program Files\Google\Chrome\Application\chrome.exe"
            };

            return Puppeteer.LaunchAsync(options, null, Product.Chrome).Result;
        }

        public static Browser CreateBrowser()
        {
            return CreateBrowserAsync().Result;
        }

        public static async Task ResetAsync(this Browser browser)
        {
            await browser.CloseAsync();
            await browser.DisposeAsync();

            browser = await CreateBrowserAsync();
        }

        public static async Task CloseAsync(this Browser browser)
        {
            await browser.CloseAsync();
            await browser.DisposeAsync();
        }
    }
}